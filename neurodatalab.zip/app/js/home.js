// Slow scroll on click Learn more
  $(document).ready(function(){
    $(".learn-more").on("click","a", function (event) {
      fullpage_api.moveSectionDown();
    });
  });

// Add fixed topbar when scroll
  $(window).scroll(function(){
    var wScroll = $(this).scrollTop();
    if (wScroll > 20) {
      $('.topbar-wrap').addClass('active');
    }
    else {
      $('.topbar-wrap').removeClass('active');
    }
  });

// Go to tab modal (login, sign-up, reset)
  $(".login-btn").click(function(){
      $('#login-popup').css('display','block');
      $('.create-btn-tab').removeClass('active');
      $('.login-btn-tab').addClass('active');
      $('#create-popup').css('display','none');
      $('#reset').css('display','none');
      $('.tab').css('display','block');
      $('#menu').removeClass('active_menu');
      $('.topnav').removeClass('active');
      $('.menu').removeClass('active');
    });

  $(".sign_up-btn").click(function(){
      $('#create-popup').css('display','block');
      $('.login-btn-tab').removeClass('active');
      $('.create-btn-tab').addClass('active');
      $('#login-popup').css('display','none');
      $('#reset').css('display','none');
      $('.tab').css('display','block');
    });

  $(".cant_login").click(function(){
      $('#reset').css('display','block');
      $('#create-popup').css('display','none');
      $('#login-popup').css('display','none');
      $('.tab').css('display','none');
    });

  $("#reset > .back").click(function() {
      $("#reset").css("display","none");
      $('#login-popup').css('display','block');
      $(".tab").css("display","block");
    });

// Demo modals
  $(".fd_1").on('click touchend', function(){
    $('.demo_fd').addClass('d-none');
    $('.fd1').removeClass('d-none');
  });
  $(".fd_2").on('click touchend', function(){
    $('.demo_fd').addClass('d-none');
    $('.fd2').removeClass('d-none');
  });
  $(".fd_3").on('click touchend', function(){
    $('.demo_fd').addClass('d-none');
    $('.fd3').removeClass('d-none');
  });
  $(".fd_4").on('click touchend', function(){
    $('.demo_fd').addClass('d-none');
    $('.fd4').removeClass('d-none');
  });
  $(".er_1").on('click touchend', function(){
    $('.demo_er').addClass('d-none');
    $('.er1').removeClass('d-none');
  });
  $(".er_2").on('click touchend', function(){
    $('.demo_er').addClass('d-none');
    $('.er2').removeClass('d-none');
  });
  $(".er_3").on('click touchend', function(){
    $('.demo_er').addClass('d-none');
    $('.er3').removeClass('d-none');
  });
  $(".er_4").on('click touchend', function(){
    $('.demo_er').addClass('d-none');
    $('.er4').removeClass('d-none');
  });
  $(".back").on('click touchend', function(){
    $('.demo_fd').removeClass('d-none');
    $('.demo_er').removeClass('d-none');
    $('.fd1').addClass('d-none');
    $('.fd2').addClass('d-none');
    $('.fd3').addClass('d-none');
    $('.fd4').addClass('d-none');
    $('.er1').addClass('d-none');
    $('.er2').addClass('d-none');
    $('.er3').addClass('d-none');
    $('.er4').addClass('d-none');
  });

// Tabs login popup
  function tab_login(evt, tab) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tab).style.display = "block";
    evt.currentTarget.className += " active";
  }

// Menu dashboard
  $('.menu').on('touch click', function(){
    $('#menu').toggleClass('active_menu');
    $('.topnav').toggleClass('active');
    $('a.menu').toggleClass('active');
  });

// Slow scroll on docs  
  // add active class to nav
  $(window).scroll(function(){
    var $sections = $('.link');
    $sections.each(function(i,el){
      if($(window).width() < 560){
        var top  = $(el).offset().top - 150;
        var bottom =  top +$(el).height();
        var scroll = $(window).scrollTop();
        var id = $(el).attr('id');
      }
      if( scroll > top && scroll < bottom){
        $('.vertical-nav > ul > li.active').removeClass('active');
        $('a[href="#'+id+'"]').parent('li').addClass('active');
      }
    })
  });
  // slow scroll
  $(document).ready(function(){
    $("#docs").on("click","a", function (event) {
      event.preventDefault();
      var id  = $(this).attr('href');
      if($(window).width() > 560){
        var top = $(id).offset().top - 100;
      }else{
        var top = $(id).offset().top - 150;
      };
      $('body,html').animate({scrollTop: top}, 800);
    });
  });

// Show hidden password
  $(function hidePass(){
    $('.hide-show').show();
    $('.hide-show span').addClass('show');
    
    $('.hide-show span').click(function(){
      if( $(this).hasClass('show') ) {
        $(this).text('Hide');
        $(this).parent().siblings('.password').attr('type','text');
        $(this).removeClass('show');
      } else {
         $(this).text('Show');
         $(this).parent().siblings('.password').attr('type','password');
         $(this).addClass('show');
      }
    });
    
    $('button.login').on('click', function(){
      $('.hide-show span').text('Show').addClass('show');
      $('.hide-show').parent().find('.password').attr('type','password');
    }); 
  });

// Show name when input focus
  var input = $('input[type="text"], input[type="password"], input[type="email"]');
  input.focus(function() {
    $(this).siblings('span').css('display','inline-block');
    $(this).css('padding','0 0 10px 10px');
    $(this).siblings('.hide-show').css('top','24px');
    $(this).parent(":before").css('top','20px');
  });
  input.blur(function() {
    if( $(this).val() ) {
      $(this).siblings('span').css('display','inline-block');
      $(this).css('padding','0 0 10px 10px');
      $(this).siblings('.hide-show').css('top','24px');
      $(this).parent(":before").css('top','20px');
    }else{
      $(this).siblings('span').css('display','none');
      $(this).css('padding','15px 15px 15px 10px');
      $(this).siblings('.hide-show').css('top','15px');
    }
  });

//info when error and else
  $(".info").text("i");
  if($(".inp-wr").hasClass("error")){
    $(".error").children(".info").text("!");
  } else{
    $(".error").children(".info").text("i");
  }

//Scrollspy

    var spy = new Gumshoe('.vertical-nav a', {
        nested: true, // if true, add classes to parents of active link
        offset: 150, // how far from the top of the page to activate a content area
        reflow: false, // if true, listen for reflows
    });

// Developed by nikoaldr@gmail.com (2019)