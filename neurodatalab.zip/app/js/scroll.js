// Scroll to next screen
  new fullpage('#fullpage', {
    licenseKey: 'F4D71089-214F4315-958D1E92-109DD6D4',
    recordHistory: false,
    sectionSelector: 'section',
    responsiveHeight: '600',
    responsiveWidth: '560',
    normalScrollElements: '.fancybox-container',    
    fitToSection: true,
    dragAndMove: true,
    scrollOverflow: false
  });

// Stop scroll when modal is open
$('[data-fancybox]').fancybox({
  touch: false,
  afterLoad: function() {
    fullpage_api.setAllowScrolling(false);
  },
  afterClose: function() {
    fullpage_api.setAllowScrolling(true);
  }
});