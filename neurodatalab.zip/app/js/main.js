// Variables
    var fd = [5,7,1,24,13,28,40,14,38,11,22,16,34,19,1,14,38,11,22];
    var er = [38,11,22,16,34,19,1,14,5,7,1,24,13,28,40,14,5,7,1];
    var time = ['Mar 1', 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30];

// Horizontall bar 100%
    new Chart(document.getElementById("bar-chart-horizontal"), {
      type: "horizontalBar",
      data: {
        labels: ["Foo"],
        datasets: [
          { label: "bad", data: [25], backgroundColor: "#9eaeff" },
          { label: "better", data: [10], backgroundColor: "rgba(255, 255, 255, 0.3)" }
        ]
      },
      options: {
        plugins: {
          stacked100: { enable: true }
        },
        legend: {
            display: false,
        },
        scales: {
            xAxes: [{
                display: false
            }],
            yAxes: [{
                display: false
            }]
        }
      }
    });

// Chart line big
    var ctx = document.getElementById('myChart').getContext("2d");

    var gradientFd = ctx.createLinearGradient(0, 0, 0, 250);
    gradientFd.addColorStop(0, 'rgba(133, 93, 248, 0.9)');
    gradientFd.addColorStop(1, 'rgba(60, 45, 169, 0.9)');

    var gradientEr = ctx.createLinearGradient(0, 0, 0, 250);
    gradientEr.addColorStop(0, 'rgba(84, 240, 255, 0.9)');
    gradientEr.addColorStop(1, 'rgba(18, 125, 176, 0.9)');

    var ChartLineBig = new Chart(ctx, {
        type: 'line',
        data: {
            labels: time,
            datasets: [
            {
                label: "Face detector",
                borderColor: gradientFd,
                pointRadius: 3,
                pointBackgroundColor: 'transparent',
                pointBorderColor: 'transparent',
                fill: true,
                backgroundColor: gradientFd,
                borderWidth: 1,
                data: fd,
                lineTension: 0
            },
            {
                label: "Emotion recognition",
                borderColor: gradientEr,
                pointRadius: 3,
                pointBackgroundColor: 'transparent',
                pointBorderColor: 'transparent',
                fill: true,
                backgroundColor: gradientEr,
                borderWidth: 1,
                data: er,
                lineTension: 0
            }
            ]
        },
        options: {
            responsive: true,
            tooltips: {
                mode: 'index',
                backgroundColor: 'rgba(30, 37, 73, 0.5)',
                titleFontFamily: 'inherit',
                height: '100%',
                position:'nearest',
                bodyFontColor: '#a9b2e1',
                bodyFontSize:14,
                bodySpacing:30,
                xPadding:20,
                yPadding:25,
                cornerRadius:0,
                multiKeyBackground: 'transparent',
                enabled: true,
                intersect:false
            },
            hover: {
                mode: 'nearest',
                intersect: true
            },
            maintainAspectRatio: false,
            legend: {
                display:false,
                position: "right",
                labels: {
                    fontColor: '#54F0FF',
                    fontSize: '14',
                    lineHeight: '20px',
                    usePointStyle:true,
                }
            },
            scales: {
                yAxes: [{
                    ticks: {
                        fontColor: "#6673B4",
                        maxTicksLimit: 5,
                        padding: 14
                    },
                    gridLines: {
                        drawTicks: true,
                        lineWidth: 1,
                        color: "rgba(102, 115, 180, 0.2)"
                    }

                }],
                xAxes: [{
                    gridLines: {
                        zeroLineColor: "#fff",
                        display: false
                    },
                    ticks: {
                        padding: 8,
                        fontColor: "#6673B4"
                    }
                }]
            }
        }
    });

    //change fill
    $('.chart-full .charts .right .icon-btn a').click(function(){
        var data_fill = $(this).attr('data-fill');
        var filling;
        if (data_fill === 'true'){
            filling = true;
            $(this).attr('data-fill','false');
        }
        if(data_fill === 'false'){
            filling = false;
            $(this).attr('data-fill','true');
        }

        ChartLineBig.data.datasets[0].fill = filling;
        ChartLineBig.data.datasets[1].fill = filling;
        ChartLineBig.update();
    });

    //change period
    $('.chart-full .charts .right .tabs a').click(function() {
        var data_time = $(this).attr('data-time');

        $('.charts .right .tabs a').removeClass('active');
        $(this).addClass('active');

        if (data_time === 'month') {
            time = ['Mar 1', 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30];
        }else if (data_time === 'year') {
            time = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        }else if (data_time === 'ever') {
            time = [2015, 2016, 2017, 2018, 2019, 2020];
        }

        ChartLineBig.data.labels = time;
        ChartLineBig.update();
    });
    
// Doughnut chart
  var ctx1 = $("#doughnut-chartcanvas-1");

  var data1 = {
    labels: ["Face detector", "Emotion recognition"],
    datasets: [
      {
        data: [85, 15],
        backgroundColor: [
          "#54f0ff",
          "#855df8"
        ],
        borderColor: [
          "#54f0ff",
          "#855df8"
        ]
      }
    ]
  };

  var chart1 = new Chart(ctx1, {
    type: "doughnut",
    data: data1,
    options: {
        responsive: true,
        title: {
            display: false
        },
        cutoutPercentage: 98,
        legend: {
            display: false
        },
        tooltips:false
    }
  });


// chartMini
  var btx = document.getElementById('myChartMini').getContext("2d");

  var myChartMini = new Chart(btx, {
      type: 'line',
      data: {
          labels: time,
          datasets: [
          {
              label: "Fd",
              borderColor: gradientFd,
              pointRadius: 3,
              pointBackgroundColor: 'transparent',
              pointBorderColor: 'transparent',
              fill: true,
              backgroundColor: gradientFd,
              borderWidth: 1,
              data: fd,
              lineTension: 0
          },
          {
              label: "Er",
              borderColor: gradientEr,
              pointRadius: 3,
              pointBackgroundColor: 'transparent',
              pointBorderColor: 'transparent',
              fill: true,
              backgroundColor: gradientEr,
              borderWidth: 1,
              data: er,
              lineTension: 0
          }
          ]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          legend: {
              display:false,
              position: "right",
              labels: {
                  fontColor: '#54F0FF',
                  fontSize: '14',
                  lineHeight: '20'
              }
          },
          scales: {
              yAxes: [{
                  ticks: {
                      fontColor: "#6673B4",
                      maxTicksLimit: 5,
                      padding: 14,
                      display:false
                  },
                  gridLines: {
                      drawTicks: true,
                      lineWidth: 1,
                      color: "rgba(102, 115, 180, 0.2)",
                      display:false
                  }

              }],
              xAxes: [{
                  gridLines: {
                      zeroLineColor: "#fff",
                      display: false
                  },
                  ticks: {
                      padding: 8,
                      fontColor: "#6673B4",
                      display:false
                  }
              }]
          }
      }
  });

  //change fill
  $('.right-bar .mini-chart .tabs a[data-fill]').click(function(){
        var data_fill = $(this).attr('data-fill');
        var filling;
        if (data_fill === 'true'){
            filling = true;
            $(this).attr('data-fill','false');
        }
        if(data_fill === 'false'){
            filling = false;
            $(this).attr('data-fill','true');
        }

        myChartMini.data.datasets[0].fill = filling;
        myChartMini.data.datasets[1].fill = filling;
        myChartMini.update();
    });

  //change period
  $('.right-bar .mini-chart .tabs a[data-time]').click(function() {
        var data_time = $(this).attr('data-time');

        if (data_time === 'month') {
            time = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            $(this).attr('data-time','year');
            $(this).text('Year');
        }else if (data_time === 'year') {
            time = [2015, 2016, 2017, 2018, 2019, 2020];
            $(this).attr('data-time','ever');
            $(this).text('Ever');
        }else if (data_time === 'ever') {
            time = ['Mar 1', 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30];
            $(this).attr('data-time','month');
            $(this).text('Month');
        }

        myChartMini.data.labels = time;
        myChartMini.update();
    });

// Payments tabs
  function thisYear(evt, year) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(year).style.display = "block";
      evt.currentTarget.className += " active";
    }

// Modal windows
  $('[data-fancybox]').fancybox({
      touch: false
  });

// Accordion
  // payments accordion
    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "table-row") {
          panel.style.display = "none";
        } else {
          panel.style.display = "table-row";
        }
      });
    }
// keys accordion
    function keysAccordion() {
        if($(window).width() < 560)
        {   
           var keyAcc = document.getElementsByClassName("keys"); 
           var j; 

           for (j = 0; j < keyAcc.length; j++) { 
             keyAcc[j].addEventListener('click', function(event) { 
               this.classList.toggle('active');

               var panel = this.nextElementSibling;

               while (panel) { 
               if (!panel.classList.contains('hidden-buttons-keys')) { 
                 break; 
               } 

               panel.classList.toggle('d-none'); 
               panel = panel.nextElementSibling; 
               } 
             }) 
           }             
        }
    }
    keysAccordion();

    $(window).resize(function() {
        keysAccordion();
    });
    
// Mobile menu fixed
  $(window).scroll(function(){
    var wScroll = $(this).scrollTop();

    if (wScroll > 90) {
      $('.mobile-nav').addClass('active');
    }
    else {
      $('.mobile-nav').removeClass('active');
    }
  });

// Menu dashboard
  $('.menu').on('touch click', function(){
        $('#menu').toggleClass('active_menu');
        $('.topnav').toggleClass('active');
        $('a.menu').toggleClass('active');
    });

// Chart mobile mini
  var ctx = document.getElementById('mobile-chart').getContext("2d");

  var myChartMobileMini = new Chart(ctx, {
      type: 'line',
      data: {
          labels: time,
          datasets: [
          {
              label: "Face detector",
              borderColor: gradientFd,
              pointRadius: 3,
              pointBackgroundColor: 'transparent',
              pointBorderColor: 'transparent',
              fill: true,
              backgroundColor: gradientFd,
              borderWidth: 1,
              data: fd,
              lineTension: 0
          },
          {
              label: "Emotion recognition",
              borderColor: gradientEr,
              pointRadius: 3,
              pointBackgroundColor: 'transparent',
              pointBorderColor: 'transparent',
              fill: true,
              backgroundColor: gradientEr,
              borderWidth: 1,
              data: er,
              lineTension: 0
          }
          ]
      },
      options: {
          responsive: true,
          tooltips: false,
          maintainAspectRatio: false,
          legend: {
              display:false
          },
          scales: {
              yAxes: [{
                  ticks: {
                      display:false,
                      beginAtZero: true
                  },
                  gridLines: {
                      display:false,
                      tickMarkLength: 0
                  }

              }],
              xAxes: [{
                  gridLines: {
                      display: false,
                      tickMarkLength: 0
                  },
                  ticks: {
                      display:false,
                      beginAtZero: true
                  }
              }]
          }
      }
  });

// Chart mobile full
  var ctx = document.getElementById('graph-mobile').getContext("2d");

  var chartMobileFull = new Chart(ctx, {
      type: 'line',
      data: {
          labels: time,
          datasets: [
          {
              label: "Face detector",
              borderColor: gradientFd,
              pointRadius: 3,
              pointBackgroundColor: 'transparent',
              pointBorderColor: 'transparent',
              fill: true,
              backgroundColor: gradientFd,
              borderWidth: 3,
              data: fd,
              lineTension: 0
          },
          {
              label: "Emotion recognition",
              borderColor: gradientEr,
              pointRadius: 3,
              pointBackgroundColor: 'transparent',
              pointBorderColor: 'transparent',
              fill: true,
              backgroundColor: gradientEr,
              borderWidth: 3,
              data: er,
              lineTension: 0
          }
          ]
      },
      options: {
          responsive: true,
          tooltips: {
              mode: 'index',
              intersect: false,
              backgroundColor: 'rgba(30, 37, 73, 0.5)',
              titleFontFamily: 'inherit',
              height: '100%',
              position:'nearest',
              bodyFontColor: '#a9b2e1',
              bodyFontSize:14,
              bodySpacing:30,
              xPadding:20,
              yPadding:25,
              cornerRadius:0,
              multiKeyBackground: 'transparent',
              enabled: true
          },
          hover: {
              mode: 'nearest',
              intersect: true
          },
          maintainAspectRatio: false,
          legend: {
              display:false,
              position: "right",
              labels: {
                  fontColor: '#54F0FF',
                  fontSize: '14',
                  lineHeight: '20px',
                  usePointStyle:true,
              }
          },
          scales: {
              yAxes: [{
                  ticks: {
                      fontColor: "#6673B4",
                      maxTicksLimit: 5,
                      padding: 14,
                      display:false,
                      beginAtZero: true
                  },
                  gridLines: {
                      drawTicks: true,
                      lineWidth: 1,
                      color: "rgba(102, 115, 180, 0.2)"
                  }

              }],
              xAxes: [{
                  gridLines: {
                      zeroLineColor: "#fff",
                      display: false
                  },
                  ticks: {
                      padding: 8,
                      fontColor: "#6673B4",
                      beginAtZero: true
                  }
              }]
          }
      }
  });
  var filling = true;

  //change fill
  $('#full-width-mobile-chart .icon-btn a').click(function(){
        var data_fill = $(this).attr('data-fill');

        if (data_fill === 'true'){
            filling = true;
            $(this).attr('data-fill','false');
        }else  if(data_fill === 'false'){
            filling = false;
            $(this).attr('data-fill','true');
        }

        chartMobileFull.data.datasets[0].fill = filling;
        chartMobileFull.data.datasets[1].fill = filling;
        chartMobileFull.update();
    });

  //change period
  $('.tabs-chart > li > a').click(function() {
        var data_time = $(this).attr('data-time');

        $('.tabs-chart li').removeClass('active');
        $(this).parent('li').addClass('active');

        if (data_time === 'month') {
            time = ['Mar 1', 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30];
        }else if (data_time === 'year') {
            time = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        }else if (data_time === 'ever') {
            time = [2015, 2016, 2017, 2018, 2019, 2020];
        }

        chartMobileFull.data.labels = time;
        chartMobileFull.update();
    });

// Mobile detail button
//   $('#mobile-dashboard-detail').click(function () {
//       $('.dashboard-info .main-info .table-wrapper:nth-child(3)').css('display','block');
//       $('.dashboard-info .main-info .table-wrapper:nth-child(2)').css('display','none');
//   });

// Visible change password
  $(".change_pass-btn").click(function(){
    $(".password").toggleClass('d-block');
  });

// Change bg near logo when dashboard is active
  if ($(".dashboard-info .dashboard_left-bar .nav .list_item:nth-child(1)").hasClass('active')) {
    $('.dashboard-info .dashboard_left-bar').addClass('active');
  }

// Show hidden password
  $(function(){
    $('.hide-show').show();
    $('.hide-show span').addClass('show');
    
    $('.hide-show span').click(function(){
      if( $(this).hasClass('show') ) {
        $(this).text('Hide');
        $(this).parent().siblings('.password').attr('type','text');
        $(this).removeClass('show');
      } else {
         $(this).text('Show');
         $(this).parent().siblings('.password').attr('type','password');
         $(this).addClass('show');
      }
    });
    
    $('.change > a').on('click', function(){
      $('.hide-show span').text('Show').addClass('show');
      $('.hide-show').parent().find('.password').attr('type','password');
    }); 
  });

// Button expand long page
$('.btn-change-long-page').click(function () {
    $('.main-info').toggleClass('long-page');
    $('.dashboard_left-bar').toggleClass('long-page');
    $('#dashboard').toggleClass('long-page');
    $('#keys').toggleClass('long-page');
    $('#users').toggleClass('long-page');
    $('#payments').toggleClass('long-page');
    $('#settings').toggleClass('long-page');
    $(this).toggleClass('collapsed');
    $('#chart-full').toggleClass('d-none');
    $('.mini-chart').removeClass('d-none');
});

// Show name when input focus
    var $input = $('input[type="text"], input[type="password"], input[type="email"]');
    if ($input.length != 0){
        $(this).siblings('span').css('display','inline-block');
    }else{
        $(this).siblings('span').css('display','none');
    }


$input.focus(function() {
    $(this).siblings('span').css('display','inline-block');
    $(this).css('padding','0 0 10px 10px');
    $(this).siblings('.hide-show').css('top','24px');
    $(this).parent(":before").css('top','20px');
});
$input.blur(function() {
    if( $(this).val() ) {
        $(this).siblings('span').css('display','inline-block');
        $(this).css('padding','0 0 10px 10px');
        $(this).siblings('.hide-show').css('top','24px');
        $(this).parent(":before").css('top','20px');
    }else{
        $(this).siblings('span').css('display','none');
        $(this).css('padding','15px 15px 15px 10px');
        $(this).siblings('.hide-show').css('top','15px');
    }
});

// Developed by nikoaldr@gmail.com (2019)